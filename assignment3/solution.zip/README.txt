**Assignment #3: Cache Simulator**

--------------------

*MS1*
Tayseer Karrossi: Makefile, main.cpp, cache.cpp
Emily Zou: cache.h

--------------------

*MS2*
Tayseer Karrossi:

- fixed implementation for load, loadToCache, store, storeToCache, getFreeIndex, emptySlot, 
  findBlock, findSetIndex, findTag, findBlockWithinSet, chooseBlockToEvict, and 
  findLeastRecentlyUsed
- implemented accessCache and updateLRU

Emily Zou:

- started implementation for load, loadToCache, store, storeToCache, getFreeIndex, emptySlot, 
  findBlock, findSetIndex, findTag, findBlockWithinSet, chooseBlockToEvict, and 
  findLeastRecentlyUsed

--------------------

*MS3*
Tayseer Karrossi:

- modified implementation for loadToCache, storeToCache, load, store, and chooseBlockToEvict
- implemented findFirstBlock

Emily Zou:

